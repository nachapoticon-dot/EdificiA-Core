# EdificIA — Bloques de Respuesta · Handoff Package

Paquete listo para Claude Code. Contiene los componentes **`.tsx`** finales (Next.js 16 + shadcn/ui + Tailwind v4 + `lucide-react` + Zod), la migración de tokens, la página de demostración, y el prototipo HTML standalone para referencia visual.

---

## Estructura

```
handoff/
├── README.md                                  ← este archivo
├── globals.css.patch                          ← 2 tokens + 1 keyframe a agregar
├── IMPLEMENTATION_GUIDE.md                    ← guía técnica completa (AI tools, Zod, refactor, a11y)
├── Bloques de Respuesta.html                  ← prototipo standalone (referencia visual)
└── src/
    ├── lib/
    │   └── validators/
    │       └── blocks.ts                      ← schemas Zod E2E (BlockSpec union)
    ├── components/
    │   └── chat/
    │       └── blocks/
    │           ├── index.tsx                  ← router ResponseBlock
    │           ├── BlockShell.tsx             ← header + slot común
    │           ├── MetricsBlock.tsx           ← KPIs + barras horizontales
    │           ├── MediaBlock.tsx             ← legajo gráfico (1 hero + 3 thumbs)
    │           ├── ComparisonBlock.tsx        ← ranking proveedores/materiales
    │           ├── TimelineBlock.tsx          ← Gantt con línea HOY + hitos
    │           ├── skeletons.tsx              ← 4 skeletons con shimmer
    │           └── demo-data.ts               ← seed para tests/Storybook
    └── app/
        └── dashboard/
            └── blocks-demo/
                └── page.tsx                   ← /dashboard/blocks-demo (reproduce conversación)
```

---

## Cómo aplicarlo

### 1. Tokens (`src/app/globals.css`)
Aplicar el patch de `globals.css.patch`. Son **2 variables nuevas** (`--green`, `--cyan`) en `:root` y `.dark`, más un `@keyframes eb-shimmer`. Nada más.

### 2. Copiar archivos
Copiar todo lo de `handoff/src/` a `src/` del repo, manteniendo la estructura. No reescribe nada existente — son archivos todos nuevos en una carpeta nueva (`components/chat/blocks/`).

### 3. Zod
El paquete asume `zod` v3 (ya está en tu `package.json`).

### 4. Probar visualmente
`npm run dev` → ir a `http://localhost:3000/dashboard/blocks-demo`. Reproduce la conversación que demuestra los 4 bloques con el ciclo tools → skeleton → bloque real.

### 5. Cablear al chat real
Editar `src/components/chat/MessageBubble.tsx` reemplazando el `SpecialToolPart` por el router del paquete — ver instrucciones detalladas en `IMPLEMENTATION_GUIDE.md` §4.

### 6. AI tools
Crear/actualizar las 4 tools server-side para que devuelvan shapes que matcheen `BlockSpec`. Detalles, mapping de intenciones y system prompt strict en `IMPLEMENTATION_GUIDE.md` §3 y §6.

---

## Convenciones que respeta

- ✅ Tailwind v4 utilities + tokens semánticos (`bg-card`, `border-border`, `text-muted-foreground`, `var(--primary)`)
- ✅ `cn()` helper desde `@/lib/utils`
- ✅ `lucide-react` exclusivo, stroke-width 1.5
- ✅ `"use client"` en todos los componentes (rendering en chat)
- ✅ Tipos derivados de Zod (`z.infer<typeof MetricsSpec>`)
- ✅ `tabular-nums` para todos los números técnicos
- ✅ Locale `es-AR` para `toLocaleString`
- ✅ `aria-busy` + `aria-label` en skeletons; `role="region"` + `aria-label` en bloques

## Componentes shadcn que NO usa (intencional)

No tira de `Card`, `Tabs`, `Table` ni `Skeleton` de shadcn porque:
1. La fidelidad visual con el resto del chat (`ChartBlock`, `ComparisonTable` actuales) es más alta usando wrappers propios.
2. Los skeletons tienen footprint personalizado que matchea cada bloque pixel-a-pixel — el `Skeleton` genérico de shadcn no sirve.
3. La grilla del Gantt requiere control fino que el `Table` de shadcn no expone.

Si tu equipo prefiere normalizarlo a shadcn primitives después, las clases utility son intercambiables — los Block* envuelven todo en un `<div>` semántico (`role="region"`).

---

## Datos de demo

`demo-data.ts` exporta 4 `BlockSpec` válidos para *Las Lomas — Torre A*. Usarlos como:
- Fixture para snapshot tests
- Seed para Storybook
- Mock en MSW para desarrollo offline
- Validación de invariantes Zod (`BlockSpec.parse(DEMO_METRICS)` debe pasar)

---

## Qué falta (entregado en la guía, no en código)

Ver `IMPLEMENTATION_GUIDE.md` para:
- AI tools server-side completas
- Migración SQL `obras.cronograma`
- Refinamiento del system prompt
- Checklist de a11y bloqueante
- Decisiones pendientes de producto

---

## Soporte

El prototipo `Bloques de Respuesta.html` es **standalone** — abrilo con doble click en el navegador, no requiere build. Sirve como referencia visual congelada de cómo deberían verse los componentes una vez aplicado todo lo del paquete.
