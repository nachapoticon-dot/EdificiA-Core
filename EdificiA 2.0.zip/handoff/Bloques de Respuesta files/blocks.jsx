// blocks.jsx
// ── EdificIA "Bloques de Respuesta" ─────────────────────────────────────────
// The four block types projected by the AI into the chat dashboard.
// Built on the existing Editorial Blueprint design tokens (terracotta + paper-
// on-ink). Each block ships with a custom Skeleton screen that mirrors its
// real footprint, so layout never shifts when the AI finishes computing.
//
// Blocks:
//   <MetricsBlock spec />        — KPIs + budget bar chart      (Recharts-shape)
//   <MediaBlock spec />          — planos / renders / obra      (DraftingCompass)
//   <ComparisonBlock spec />     — proveedores / materiales     (Layers)
//   <TimelineBlock spec />       — cronograma estilo Gantt      (HardHat)
//
//   <MetricsSkeleton />          — mirrors metric KPI strip + chart
//   <MediaSkeleton />            — 1 hero + 3 thumbs grid
//   <ComparisonSkeleton />       — header + 4 rows
//   <TimelineSkeleton />         — 5 Gantt rows
//
// Each block is wrapped in a shared <BlockShell> that renders the fig-label
// header ("FIG. 02 · TIMELINE · n = 5") consistent with the existing
// ChartBlock and ComparisonTable.

const { useEffect, useState, useMemo, useRef } = React;

// ── Money / unit formatters ─────────────────────────────────────────────────
const fmtAR = (n) => (n ?? 0).toLocaleString("es-AR");
const fmt$ = (n) => `$${fmtAR(Math.round(n))}`;
const fmtPct = (n) => `${n.toFixed(1)}%`;

// ── Shared shell ────────────────────────────────────────────────────────────
function BlockShell({ icon: Icon, fig, title, meta, accent, children, footer, dense = false }) {
  return (
    <div className="eb-block eb-num">
      <div className="eb-block-hd">
        <div className="eb-block-hd-l">
          <div className="eb-block-icon" style={{ color: accent || "var(--primary)" }}>
            {Icon ? <Icon size={14} /> : null}
          </div>
          <div>
            <div className="eb-block-title">{title}</div>
            <div className="eb-block-fig">{fig}{meta ? <> · {meta}</> : null}</div>
          </div>
        </div>
        <div className="eb-block-hd-r">
          <button className="eb-icon-btn" title="Abrir en panel"><Maximize2 size={12} /></button>
          <button className="eb-icon-btn" title="Exportar"><Download size={12} /></button>
        </div>
      </div>
      <div className={dense ? "eb-block-body eb-block-body-dense" : "eb-block-body"}>
        {children}
      </div>
      {footer ? <div className="eb-block-ft">{footer}</div> : null}
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// METRICS BLOCK
// ────────────────────────────────────────────────────────────────────────────
function MetricsBlock({ spec, accent }) {
  const { title, kpis, bars, totalLabel = "Σ", footer } = spec;
  const max = Math.max(...bars.map(b => b.value)) * 1.1 || 1;

  return (
    <BlockShell
      icon={Building2}
      fig="FIG. 02 · METRICS"
      title={title}
      meta={`n = ${bars.length}`}
      accent={accent}
      footer={footer ? <span className="eb-mono-muted">{footer}</span> : null}
    >
      {/* KPI strip */}
      <div className="eb-kpi-grid">
        {kpis.map((k, i) => (
          <div key={i} className="eb-kpi">
            <div className="eb-kpi-label">{k.label}</div>
            <div className="eb-kpi-row">
              <div className="eb-kpi-val">{k.value}</div>
              {k.delta != null && (
                <div className={"eb-kpi-delta " + (k.delta > 0 ? "is-up" : "is-down") + (k.alert ? " is-alert" : "")}>
                  {k.delta > 0 ? <TrendingUp size={11}/> : <TrendingDown size={11}/>}
                  <span>{k.delta > 0 ? "+" : ""}{k.delta.toFixed(1)}%</span>
                </div>
              )}
            </div>
            {k.sub && <div className="eb-kpi-sub">{k.sub}</div>}
          </div>
        ))}
      </div>

      {/* Bar chart — horizontal, mirrors ChartBlock visual idiom */}
      <div className="eb-bar-wrap">
        <div className="eb-bar-axis-label">
          <span>RUBRO</span>
          <span>INCIDENCIA</span>
        </div>
        <div className="eb-bars">
          {bars.map((b, i) => {
            const pct = (b.value / max) * 100;
            const color = b.alert ? "var(--warn)" : (accent || "var(--primary)");
            return (
              <div key={i} className="eb-bar-row">
                <span className="eb-bar-name" title={b.label}>{b.label}</span>
                <div className="eb-bar-track">
                  <div className="eb-bar-fill" style={{ width: pct + "%", background: color }} />
                  {pct > 24 && (
                    <span className="eb-bar-inline">{fmt$(b.value)}</span>
                  )}
                </div>
                <span className="eb-bar-val" style={{ color }}>{b.pct ? fmtPct(b.pct) : fmt$(b.value)}</span>
              </div>
            );
          })}
        </div>
        <div className="eb-bar-total">
          <span className="eb-mono-muted">{totalLabel}</span>
          <span>{fmt$(bars.reduce((s, b) => s + b.value, 0))}</span>
        </div>
      </div>
    </BlockShell>
  );
}

function MetricsSkeleton() {
  return (
    <BlockShell icon={Building2} fig="FIG. 02 · METRICS" title="Calculando métricas de obra…" meta="cargando…">
      <div className="eb-kpi-grid">
        {[0,1,2,3].map(i => (
          <div key={i} className="eb-kpi">
            <div className="sk sk-line" style={{ width: 48 }}/>
            <div className="sk sk-line sk-lg" style={{ width: 84 }}/>
            <div className="sk sk-line" style={{ width: 52, opacity: .5 }}/>
          </div>
        ))}
      </div>
      <div className="eb-bar-wrap">
        <div className="eb-bar-axis-label"><span>RUBRO</span><span>INCIDENCIA</span></div>
        <div className="eb-bars">
          {[0,1,2,3,4].map(i => (
            <div key={i} className="eb-bar-row">
              <span className="sk sk-line eb-sk-name"/>
              <div className="eb-bar-track"><div className="sk-bar" style={{ width: (80 - i*12) + "%" }}/></div>
              <span className="sk sk-line eb-sk-tail"/>
            </div>
          ))}
        </div>
      </div>
    </BlockShell>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// MEDIA BLOCK
// ────────────────────────────────────────────────────────────────────────────
const MEDIA_KIND = {
  plano:  { label: "PLANO",       icon: DraftingCompass, color: "var(--cyan)" },
  render: { label: "RENDER",      icon: Image,           color: "var(--primary)" },
  obra:   { label: "INSPECCIÓN",  icon: Camera,          color: "var(--green)" },
};

// Custom illustrative SVG placeholders rendered into the cards so the
// prototype looks like real building media without copying any product photo.
function MediaThumb({ item, hero = false }) {
  const k = MEDIA_KIND[item.kind] ?? MEDIA_KIND.plano;
  const Ico = k.icon;
  return (
    <div className={"eb-media-tile " + (hero ? "is-hero" : "")} title={item.title}>
      <div className="eb-media-canvas" data-kind={item.kind}>
        {item.kind === "plano" && <PlanoArt seed={item.seed ?? 1} />}
        {item.kind === "render" && <RenderArt seed={item.seed ?? 1} />}
        {item.kind === "obra" && <ObraArt seed={item.seed ?? 1} />}
        <div className="eb-media-grid" />
      </div>
      <div className="eb-media-meta">
        <span className="eb-media-badge" style={{ color: k.color, borderColor: k.color }}>
          <Ico size={10}/> {k.label}
        </span>
        <div className="eb-media-title">{item.title}</div>
        <div className="eb-media-sub">
          {item.date && <span><Calendar size={10}/> {item.date}</span>}
          {item.location && <span><MapPin size={10}/> {item.location}</span>}
          {item.ext && <span className="eb-mono-muted">{item.ext}</span>}
        </div>
      </div>
      <button className="eb-media-zoom" title="Ampliar"><Maximize2 size={12}/></button>
    </div>
  );
}

// Schematic blueprint of a floor plan — purely decorative
function PlanoArt({ seed = 1 }) {
  const off = seed * 6;
  return (
    <svg viewBox="0 0 240 160" className="eb-art">
      <defs>
        <pattern id={`hatch${seed}`} width="6" height="6" patternUnits="userSpaceOnUse">
          <path d="M0 6L6 0" stroke="currentColor" strokeWidth=".4" opacity=".25"/>
        </pattern>
      </defs>
      <g fill="none" stroke="currentColor" strokeWidth="1.2" opacity=".85">
        <rect x="14" y="14" width="212" height="132" rx="1"/>
        <line x1="14" y1={64 + (off%18)} x2="138" y2={64 + (off%18)}/>
        <line x1="138" y1={64 + (off%18)} x2="138" y2="146"/>
        <line x1="170" y1="14" x2="170" y2="92"/>
        <line x1="170" y1="92" x2="226" y2="92"/>
        <line x1="60" y1="14" x2="60" y2={64 + (off%18)}/>
      </g>
      <g stroke="currentColor" strokeWidth=".7" opacity=".4">
        <line x1="20" y1="20" x2="220" y2="20" strokeDasharray="2 2"/>
        <line x1="20" y1="140" x2="220" y2="140" strokeDasharray="2 2"/>
        <text x="120" y="10" fontSize="6" textAnchor="middle" fontFamily="ui-monospace,monospace">12.40m</text>
        <text x="232" y="80" fontSize="6" textAnchor="middle" fontFamily="ui-monospace,monospace" transform="rotate(90 232 80)">7.20m</text>
      </g>
      <rect x="14" y="14" width="212" height="132" fill={`url(#hatch${seed})`}/>
    </svg>
  );
}

function RenderArt({ seed = 1 }) {
  const hue = 30 + seed * 8;
  return (
    <svg viewBox="0 0 240 160" className="eb-art" preserveAspectRatio="xMidYMid slice">
      <defs>
        <linearGradient id={`sky${seed}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={`oklch(0.62 0.04 ${hue})`}/>
          <stop offset="1" stopColor={`oklch(0.42 0.05 ${hue + 20})`}/>
        </linearGradient>
      </defs>
      <rect width="240" height="160" fill={`url(#sky${seed})`}/>
      <g opacity=".9">
        <rect x="30"  y="60"  width="56"  height="92" fill="oklch(0.30 0.02 40)"/>
        <rect x="92"  y="38"  width="60"  height="114" fill="oklch(0.38 0.025 38)"/>
        <rect x="160" y="74"  width="56"  height="78"  fill="oklch(0.32 0.02 42)"/>
        {/* Windows */}
        {[0,1,2,3].map(r => [0,1,2].map(c => (
          <rect key={`a${r}${c}`} x={36 + c*16} y={66 + r*18} width="10" height="10" fill="oklch(0.72 0.10 70)" opacity={(r+c+seed)%2 ? .9 : .4}/>
        )))}
        {[0,1,2,3,4].map(r => [0,1,2].map(c => (
          <rect key={`b${r}${c}`} x={98 + c*16} y={44 + r*20} width="10" height="12" fill="oklch(0.72 0.10 70)" opacity={(r+c+seed)%3 ? .85 : .35}/>
        )))}
      </g>
      <rect x="0" y="148" width="240" height="12" fill="oklch(0.2 0.01 30)"/>
    </svg>
  );
}

function ObraArt({ seed = 1 }) {
  return (
    <svg viewBox="0 0 240 160" className="eb-art" preserveAspectRatio="xMidYMid slice">
      <rect width="240" height="160" fill="oklch(0.32 0.02 70)"/>
      {/* Sky */}
      <rect width="240" height="80" fill="oklch(0.48 0.03 220)"/>
      {/* Crane */}
      <g stroke="oklch(0.78 0.14 70)" strokeWidth="1.5" fill="none">
        <line x1={40+seed*3} y1="20" x2={40+seed*3} y2="120"/>
        <line x1={40+seed*3} y1="30" x2="180" y2="30"/>
        <line x1={40+seed*3} y1="34" x2="178" y2="40"/>
        <line x1="120" y1="30" x2="120" y2="62"/>
        <rect x="113" y="62" width="14" height="10" fill="oklch(0.78 0.14 70)"/>
      </g>
      {/* Building skeleton */}
      <g stroke="oklch(0.55 0.03 50)" strokeWidth="1" fill="oklch(0.42 0.02 50)" opacity=".95">
        <rect x="60" y="70" width="160" height="80"/>
        {[0,1,2].map(r => <line key={r} x1="60" y1={90 + r*20} x2="220" y2={90 + r*20}/>)}
        {[0,1,2,3,4,5,6,7].map(c => <line key={c} x1={60 + c*20} y1="70" x2={60 + c*20} y2="150"/>)}
      </g>
      {/* Foreground earth */}
      <path d="M0 150 L240 145 L240 160 L0 160 Z" fill="oklch(0.30 0.04 55)"/>
    </svg>
  );
}

function MediaBlock({ spec, accent }) {
  const [hero, ...rest] = spec.items;
  return (
    <BlockShell
      icon={DraftingCompass}
      fig="FIG. 03 · MEDIA"
      title={spec.title}
      meta={`${spec.items.length} adjuntos`}
      accent={accent}
      footer={
        <span className="eb-mono-muted">
          legajo · <span className="eb-hl">{spec.obra}</span> · sync {spec.synced ?? "hace 4m"}
        </span>
      }
      dense
    >
      <div className="eb-media-grid-wrap">
        <MediaThumb item={hero} hero />
        <div className="eb-media-side">
          {rest.map((it, i) => <MediaThumb key={i} item={it} />)}
        </div>
      </div>
    </BlockShell>
  );
}

function MediaSkeleton() {
  return (
    <BlockShell icon={DraftingCompass} fig="FIG. 03 · MEDIA" title="Cargando legajo gráfico…" meta="indexando" dense>
      <div className="eb-media-grid-wrap">
        <div className="eb-media-tile is-hero">
          <div className="sk sk-block eb-sk-hero"/>
          <div className="eb-media-meta">
            <div className="sk sk-line" style={{ width: 70 }}/>
            <div className="sk sk-line sk-lg" style={{ width: 180 }}/>
            <div className="sk sk-line" style={{ width: 120, opacity: .5 }}/>
          </div>
        </div>
        <div className="eb-media-side">
          {[0,1,2].map(i => (
            <div key={i} className="eb-media-tile">
              <div className="sk sk-block eb-sk-thumb"/>
              <div className="eb-media-meta">
                <div className="sk sk-line" style={{ width: 60 }}/>
                <div className="sk sk-line sk-lg" style={{ width: 110 }}/>
              </div>
            </div>
          ))}
        </div>
      </div>
    </BlockShell>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// COMPARISON BLOCK (proveedores / materiales)
// ────────────────────────────────────────────────────────────────────────────
function ComparisonBlock({ spec, accent }) {
  const ranked = useMemo(
    () => spec.items.map(it => {
      const score = it.score;
      return { ...it, score };
    }).sort((a, b) => b.score - a.score),
    [spec.items]
  );
  const recommended = ranked[0];

  return (
    <BlockShell
      icon={Layers}
      fig="FIG. 04 · COMPARATIVE"
      title={spec.title}
      meta={`${spec.items.length} ${spec.unit ?? "opciones"}`}
      accent={accent}
      footer={
        <span className="eb-mono-muted">
          ranking por <span className="eb-hl">{spec.rankBy ?? "score técnico-comercial"}</span>
        </span>
      }
    >
      <div className="eb-comp-head">
        <span>OPCIÓN</span>
        {spec.cols.map((c, i) => <span key={i}>{c.label}</span>)}
        <span>SCORE</span>
      </div>
      {ranked.map((row, i) => {
        const isRec = row.name === recommended.name;
        return (
          <div key={row.name} className={"eb-comp-row" + (isRec ? " is-rec" : "")}>
            <div className="eb-comp-name">
              <div className="eb-comp-rank">{i + 1}</div>
              <div>
                <div className="eb-comp-title">
                  {row.name}
                  {isRec && (
                    <span className="eb-rec-badge" style={{ background: accent || "var(--primary)" }}>
                      <CheckCircle2 size={10}/> RECOMENDADO
                    </span>
                  )}
                </div>
                {row.sub && <div className="eb-comp-sub">{row.sub}</div>}
              </div>
            </div>
            {spec.cols.map((c, j) => {
              const v = row.values[c.key];
              const isAlert = c.alertWhen && c.alertWhen(v);
              return (
                <div key={j} className={"eb-comp-cell" + (isAlert ? " is-alert" : "")}>
                  <span className="eb-cell-val">{c.fmt ? c.fmt(v) : v}</span>
                  {c.sub && <span className="eb-cell-sub">{c.sub(row)}</span>}
                </div>
              );
            })}
            <div className="eb-comp-score">
              <div className="eb-score-bar">
                <div className="eb-score-bar-fill"
                  style={{ width: row.score + "%", background: isRec ? (accent || "var(--primary)") : "var(--muted-foreground)" }}/>
              </div>
              <span className="eb-score-val">{row.score}</span>
            </div>
          </div>
        );
      })}
    </BlockShell>
  );
}

function ComparisonSkeleton() {
  return (
    <BlockShell icon={Layers} fig="FIG. 04 · COMPARATIVE" title="Cotejando proveedores…" meta="consultando índices">
      <div className="eb-comp-head">
        <span>OPCIÓN</span><span>PRECIO</span><span>PLAZO</span><span>CALIDAD</span><span>SCORE</span>
      </div>
      {[0,1,2,3].map(i => (
        <div key={i} className="eb-comp-row">
          <div className="eb-comp-name">
            <div className="sk eb-sk-rank"/>
            <div style={{ flex: 1 }}>
              <div className="sk sk-line sk-lg" style={{ width: 140 }}/>
              <div className="sk sk-line" style={{ width: 90, opacity: .5 }}/>
            </div>
          </div>
          {[0,1,2].map(j => (
            <div key={j} className="eb-comp-cell"><div className="sk sk-line" style={{ width: 60 }}/></div>
          ))}
          <div className="eb-comp-score">
            <div className="eb-score-bar"><div className="sk-bar" style={{ width: (75 - i*12) + "%" }}/></div>
          </div>
        </div>
      ))}
    </BlockShell>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// TIMELINE BLOCK (Gantt-style)
// ────────────────────────────────────────────────────────────────────────────
function TimelineBlock({ spec, accent }) {
  // Phases are days-from-start spans. We compute a shared scale.
  const { phases, totalDays, todayDay, milestones = [], title } = spec;
  const months = spec.months ?? ["Ene","Feb","Mar","Abr","May","Jun"];

  return (
    <BlockShell
      icon={HardHat}
      fig="FIG. 05 · TIMELINE"
      title={title}
      meta={`${totalDays}d · ${phases.length} etapas`}
      accent={accent}
      footer={
        <span className="eb-mono-muted">
          hoy <span className="eb-hl">día {todayDay}</span> · {Math.round((todayDay / totalDays) * 100)}% transcurrido
        </span>
      }
    >
      {/* Month/scale header */}
      <div className="eb-tl-axis">
        <span className="eb-tl-pad"/>
        <div className="eb-tl-scale">
          {months.map((m, i) => (
            <div key={i} className="eb-tl-tick">
              <span className="eb-tl-tick-label">{m}</span>
              <span className="eb-tl-tick-line"/>
            </div>
          ))}
          {/* Today line */}
          <div className="eb-tl-today" style={{ left: `${(todayDay / totalDays) * 100}%` }}>
            <span className="eb-tl-today-pin">HOY</span>
          </div>
        </div>
      </div>

      {/* Phases */}
      <div className="eb-tl-rows">
        {phases.map((p, i) => {
          const left = (p.start / totalDays) * 100;
          const width = ((p.end - p.start) / totalDays) * 100;
          const done = Math.min(100, Math.max(0, ((Math.min(todayDay, p.end) - p.start) / (p.end - p.start)) * 100));
          const status = p.end < todayDay ? "done" : (p.start <= todayDay ? "in-progress" : "pending");
          return (
            <div key={i} className={"eb-tl-row is-" + status}>
              <div className="eb-tl-name">
                <span className="eb-tl-dot" style={{ background: status === "done" ? "var(--green)" : status === "in-progress" ? (accent || "var(--primary)") : "var(--paper-500)" }}/>
                <span className="eb-tl-name-text">{p.name}</span>
                <span className="eb-tl-name-sub">{p.crew}</span>
              </div>
              <div className="eb-tl-track">
                <div className="eb-tl-bar" style={{ left: `${left}%`, width: `${width}%`, background: status === "done" ? "var(--green)" : (accent || "var(--primary)") }}>
                  <div className="eb-tl-bar-progress" style={{ width: status === "pending" ? "0%" : `${done}%` }}/>
                  <span className="eb-tl-bar-label">{p.name}</span>
                  <span className="eb-tl-bar-pct">{Math.round(done)}%</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Milestones */}
      {milestones.length > 0 && (
        <div className="eb-tl-milestones">
          <div className="eb-tl-ms-label">HITOS</div>
          <div className="eb-tl-ms-list">
            {milestones.map((m, i) => (
              <div key={i} className={"eb-tl-ms" + (m.day < todayDay ? " is-past" : "")}>
                <div className="eb-tl-ms-dot"/>
                <div>
                  <div className="eb-tl-ms-title">{m.label}</div>
                  <div className="eb-tl-ms-sub">día {m.day} · {m.note}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </BlockShell>
  );
}

function TimelineSkeleton() {
  return (
    <BlockShell icon={HardHat} fig="FIG. 05 · TIMELINE" title="Calculando cronograma de avance…" meta="estimando holguras">
      <div className="eb-tl-axis">
        <span className="eb-tl-pad"/>
        <div className="eb-tl-scale">
          {[0,1,2,3,4,5].map(i => <div key={i} className="eb-tl-tick"><span className="sk sk-line" style={{ width: 22 }}/></div>)}
        </div>
      </div>
      <div className="eb-tl-rows">
        {[0,1,2,3,4].map(i => (
          <div key={i} className="eb-tl-row">
            <div className="eb-tl-name">
              <span className="sk eb-sk-tldot"/>
              <div style={{ flex: 1 }}>
                <div className="sk sk-line sk-lg" style={{ width: 130 }}/>
                <div className="sk sk-line" style={{ width: 70, opacity: .5 }}/>
              </div>
            </div>
            <div className="eb-tl-track">
              <div className="sk-bar eb-sk-tlbar" style={{ left: (5 + i*12) + "%", width: (38 - i*4) + "%" }}/>
            </div>
          </div>
        ))}
      </div>
    </BlockShell>
  );
}

// ── Block router (used by the chat) ─────────────────────────────────────────
function ResponseBlock({ kind, spec, loading, accent }) {
  if (loading) {
    if (kind === "metrics")    return <MetricsSkeleton />;
    if (kind === "media")      return <MediaSkeleton />;
    if (kind === "comparison") return <ComparisonSkeleton />;
    if (kind === "timeline")   return <TimelineSkeleton />;
  }
  if (kind === "metrics")    return <MetricsBlock spec={spec} accent={accent} />;
  if (kind === "media")      return <MediaBlock spec={spec} accent={accent} />;
  if (kind === "comparison") return <ComparisonBlock spec={spec} accent={accent} />;
  if (kind === "timeline")   return <TimelineBlock spec={spec} accent={accent} />;
  return null;
}

Object.assign(window, {
  MetricsBlock, MediaBlock, ComparisonBlock, TimelineBlock,
  MetricsSkeleton, MediaSkeleton, ComparisonSkeleton, TimelineSkeleton,
  ResponseBlock, BlockShell,
});
