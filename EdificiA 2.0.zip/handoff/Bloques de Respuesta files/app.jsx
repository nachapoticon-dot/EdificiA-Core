// app.jsx
// ── EdificIA chat dashboard — "Bloques de Respuesta" prototype ─────────────
// Renders the scripted CONVERSATION with skeleton-first animations for each
// response block, a chat input, and a Tweaks panel that toggles accent / view.

const { useState, useEffect, useRef, useCallback } = React;

// ── Defaults (host-rewritable) ──────────────────────────────────────────────
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "verde",
  "skeletonHold": 1200,
  "showAllSkeletons": false,
  "density": "comfy",
  "showToolTimeline": true
}/*EDITMODE-END*/;

const ACCENT_MAP = {
  terracota: "var(--terra-400)",
  verde:     "var(--green)",
  cian:      "var(--cyan)",
  ambar:     "var(--warn)",
};

// ── Tool labels (mirrors MessageBubble.tsx) ─────────────────────────────────
const TOOL_LABELS = {
  calcular_totales:                "Calculando totales del presupuesto",
  calcular_incidencia_de_subgrupo: "Calculando incidencia por rubro",
  comparar_con_indices:            "Comparando contra índices CAC abr-2026",
  buscar_en_base_documental:       "Buscando en legajo técnico",
  analizar_geometria_plano:        "Analizando geometría del plano",
  comparar_presupuestos:           "Cotejando proveedores",
  analizar_estado_obra:            "Analizando estado de obra",
};

// ────────────────────────────────────────────────────────────────────────────
// FILE ATTACHMENT (mirrors FileAttachmentCard from MessageBubble.tsx)
// ────────────────────────────────────────────────────────────────────────────
function FileChip({ file }) {
  const Icon = file.type === "excel" ? FileSpreadsheet
             : file.type === "pdf"   ? FileText
             : file.type === "dxf"   ? FileCode2 : FileText;
  const color = file.type === "excel" ? "var(--green)"
              : file.type === "pdf"   ? "var(--destructive)"
              : file.type === "dxf"   ? "var(--cyan)" : "var(--paper-300)";
  return (
    <div className="eb-file-chip">
      <Icon size={14} style={{ color }} />
      <div style={{ minWidth: 0 }}>
        <div className="eb-file-name">{file.name}</div>
        {file.sub && <div className="eb-file-sub">{file.sub}</div>}
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// TOOL TIMELINE (running tools pill row)
// ────────────────────────────────────────────────────────────────────────────
function ToolTimeline({ tools, done }) {
  return (
    <div className="eb-tool-card">
      {tools.map((t, i) => (
        <div key={t} className={"eb-tool-row" + (done ? " is-done" : "")}>
          <span className={done ? "eb-tool-dot is-done" : "eb-tool-dot eb-pulse"}>
            {done ? <CheckCircle2 size={12} /> : <Dot size={12}/>}
          </span>
          <Wrench size={11} />
          <span className="eb-tool-name">{TOOL_LABELS[t] ?? t}</span>
          <span className={done ? "eb-tool-state is-done" : "eb-tool-state eb-pulse"}>
            {done ? "ok" : "en curso…"}
          </span>
        </div>
      ))}
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// MESSAGE BUBBLE
// ────────────────────────────────────────────────────────────────────────────
function MarkdownLite({ text }) {
  // tiny safe inline parser: **bold**, *italic*, `code`
  const parts = [];
  const regex = /(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)/g;
  let last = 0; let m;
  while ((m = regex.exec(text)) !== null) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    const t = m[0];
    if (t.startsWith("**")) parts.push(<strong key={m.index}>{t.slice(2, -2)}</strong>);
    else if (t.startsWith("`")) parts.push(<code key={m.index} className="eb-inline-code">{t.slice(1, -1)}</code>);
    else parts.push(<em key={m.index}>{t.slice(1, -1)}</em>);
    last = m.index + t.length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return <>{parts}</>;
}

function Bubble({ msg, blockState, accentVar, showToolTimeline }) {
  const isUser = msg.role === "user";
  return (
    <div className={"eb-msg " + (isUser ? "is-user" : "is-bot")}>
      {!isUser && (
        <div className="eb-avatar">
          <span style={{ fontStyle: "italic" }}>E</span>
        </div>
      )}
      <div className="eb-msg-body">
        <div className="eb-msg-meta">
          {isUser ? "vos" : "EdificIA"} · {msg.time}
        </div>

        {/* User: file chip + text */}
        {isUser && msg.file && <FileChip file={msg.file} />}
        {msg.text && (
          <div className={isUser ? "eb-bubble eb-bubble-user" : "eb-bubble eb-bubble-bot"}>
            <MarkdownLite text={msg.text} />
          </div>
        )}

        {/* Bot: tool timeline (during work or done) */}
        {!isUser && msg.tools && showToolTimeline && (
          <ToolTimeline tools={msg.tools} done={blockState !== "tools"} />
        )}

        {/* Bot: response block (skeleton → real) */}
        {!isUser && msg.block && blockState !== "tools" && (
          <ResponseBlock
            kind={msg.block.kind}
            spec={msg.block.spec}
            loading={blockState === "skeleton"}
            accent={accentVar}
          />
        )}
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// SIDEBAR
// ────────────────────────────────────────────────────────────────────────────
function Sidebar() {
  return (
    <aside className="eb-side">
      {/* Org switcher */}
      <div className="eb-org">
        <div className="eb-org-mark">EA</div>
        <div style={{ minWidth: 0, flex: 1 }}>
          <div className="eb-org-name">Estudio Argañaraz <span className="eb-mono-muted">· founder</span></div>
          <div className="eb-org-sub">3 obras activas · 24 miembros</div>
        </div>
        <ChevronDown size={14}/>
      </div>

      {/* Active project */}
      <div className="eb-section-label">OBRA ACTIVA</div>
      <div className="eb-active-obra">
        <div className="eb-active-obra-top">
          <Building2 size={14} style={{ color: "var(--primary)" }}/>
          <div className="eb-active-obra-name">Las Lomas — Torre A</div>
          <span className="eb-tag">EN OBRA</span>
        </div>
        <div className="eb-obra-meta">
          <div><span className="eb-mono-muted">CÓDIGO</span><span>LL-2024-01</span></div>
          <div><span className="eb-mono-muted">UBIC.</span><span>Tigre, BA</span></div>
          <div><span className="eb-mono-muted">CONTRATO</span><span>$128.45M</span></div>
        </div>
        <div className="eb-cover">
          <div className="eb-cover-bar"><div className="eb-cover-fill" style={{ width: "78%" }}/></div>
          <span className="eb-mono-muted">cobertura documental · 78%</span>
        </div>
      </div>

      {/* History */}
      <div className="eb-section-label" style={{ marginTop: 16 }}>HISTORIAL</div>
      <button className="eb-new-session">
        <Plus size={13}/> Nueva conversación
      </button>
      {[
        { icon: FileSpreadsheet, title: "Auditoría presupuesto R3", time: "ahora", active: true },
        { icon: FileCode2,       title: "Plano arquitectura R7",     time: "hace 2h" },
        { icon: FileText,        title: "Comparativo proveedores",   time: "hace 1d" },
        { icon: FileText,        title: "Memoria descriptiva v2",    time: "hace 2d" },
        { icon: FileSpreadsheet, title: "Cómputo de revoques",       time: "hace 4d" },
      ].map((s, i) => {
        const Ico = s.icon;
        return (
          <button key={i} className={"eb-session-item" + (s.active ? " is-active" : "")}>
            <Ico size={12}/>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="eb-session-title">{s.title}</div>
              <div className="eb-session-time">{s.time}</div>
            </div>
          </button>
        );
      })}

      {/* Bottom — agent context */}
      <div style={{ flex: 1 }}/>
      <div className="eb-agent-context">
        <div className="eb-section-label">AGENTE</div>
        <div className="eb-agent-row">
          <span className="eb-mono-muted">tono</span><span>Auditor Técnico Sr.</span>
        </div>
        <div className="eb-agent-row">
          <span className="eb-mono-muted">RAG</span><span>1 482 chunks indexados</span>
        </div>
        <div className="eb-agent-row">
          <span className="eb-mono-muted">modelo</span><span>claude-sonnet · v5</span>
        </div>
      </div>
    </aside>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// HEADER
// ────────────────────────────────────────────────────────────────────────────
function Header({ onReplay, accent, onAccent, density, onDensity }) {
  return (
    <header className="eb-header">
      <div className="eb-header-l">
        <span className="eb-mono-muted">DASHBOARD ›</span>
        <span>Chat con contexto · <strong>Las Lomas — Torre A</strong></span>
      </div>
      <div className="eb-header-r">
        <div className="eb-status">
          <span className="eb-dot is-ok eb-pulse"/>
          <span>Qdrant · Postgres · Claude</span>
          <span className="eb-mono-muted">operativos</span>
        </div>
        <button className="eb-header-btn" onClick={onReplay} title="Reproducir desde el inicio">
          <Sparkles size={13}/> Reproducir demo
        </button>
        <button className="eb-icon-btn"><Search size={14}/></button>
        <button className="eb-icon-btn"><Settings size={14}/></button>
      </div>
    </header>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// CHAT INPUT
// ────────────────────────────────────────────────────────────────────────────
function ChatInput({ onSend }) {
  const [v, setV] = useState("");
  return (
    <div className="eb-input-wrap">
      <div className="eb-input-suggestions">
        {[
          "¿Hay desvíos sobre el CAC en estructura?",
          "Generar informe de auditoría PDF",
          "Ver hitos críticos próximos 30 días",
        ].map((s) => (
          <button key={s} className="eb-chip" onClick={() => onSend?.(s)}>{s}</button>
        ))}
      </div>
      <div className="eb-input">
        <button className="eb-icon-btn" title="Adjuntar archivo"><Paperclip size={15}/></button>
        <input
          className="eb-input-field"
          placeholder="Enviá datos o hacé una pregunta…"
          value={v}
          onChange={(e) => setV(e.target.value)}
        />
        <button className="eb-input-send" title="Enviar"><ArrowUp size={15}/></button>
      </div>
      <div className="eb-input-hint">
        <span className="eb-mono-muted">⏎ enviar · ⇧⏎ nueva línea · @ obra · # documento</span>
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// MAIN APP
// ────────────────────────────────────────────────────────────────────────────
function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const accentVar = ACCENT_MAP[t.accent] ?? ACCENT_MAP.verde;

  // Visible messages + per-message block state
  // states for assistant block: "tools" → "skeleton" → "ready"
  const [visible, setVisible] = useState([]); // ids in order
  const [blockState, setBlockState] = useState({}); // id → state
  const [tick, setTick] = useState(0); // re-run trigger
  const scrollRef = useRef(null);

  // Play conversation step-by-step on mount & whenever tick changes
  useEffect(() => {
    let cancelled = false;
    setVisible([]);
    setBlockState({});

    const run = async () => {
      for (let i = 0; i < CONVERSATION.length; i++) {
        const msg = CONVERSATION[i];
        await sleep(i === 0 ? 200 : 700);
        if (cancelled) return;
        setVisible((v) => [...v, msg.id]);

        if (msg.role === "assistant") {
          // tools-first phase if tools exist
          if (msg.tools) {
            setBlockState((s) => ({ ...s, [msg.id]: "tools" }));
            await sleep(1200);
            if (cancelled) return;
          }
          // skeleton phase
          if (msg.block) {
            setBlockState((s) => ({ ...s, [msg.id]: "skeleton" }));
            await sleep(t.skeletonHold);
            if (cancelled) return;
            setBlockState((s) => ({ ...s, [msg.id]: "ready" }));
          }
        }

        // autoscroll
        requestAnimationFrame(() => {
          if (scrollRef.current) {
            scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
          }
        });
      }
    };
    run();
    return () => { cancelled = true; };
  }, [tick, t.skeletonHold]);

  // forced skeleton override
  const effectiveState = (msg) => {
    const st = blockState[msg.id];
    if (!st) return st;
    if (t.showAllSkeletons && msg.block) return "skeleton";
    return st;
  };

  const visibleMessages = CONVERSATION.filter((m) => visible.includes(m.id));

  return (
    <div className={"eb-app eb-density-" + t.density} data-theme="dark">
      <Sidebar />

      <main className="eb-main">
        <Header
          onReplay={() => setTick((x) => x + 1)}
          accent={t.accent}
        />

        <div className="eb-chat-scroll" ref={scrollRef}>
          <div className="eb-chat-day">
            <span/>
            <span className="eb-mono-muted">Lunes 12 de mayo · 09:14</span>
            <span/>
          </div>

          {visibleMessages.map((m) => (
            <Bubble
              key={m.id}
              msg={m}
              blockState={effectiveState(m)}
              accentVar={accentVar}
              showToolTimeline={t.showToolTimeline}
            />
          ))}

          <div style={{ height: 24 }}/>
        </div>

        <div className="eb-input-zone">
          <ChatInput onSend={() => setTick((x) => x + 1)}/>
        </div>
      </main>

      {/* Tweaks panel */}
      <TweaksPanel title="Tweaks">
        <TweakSection label="Sistema visual"/>
        <TweakRadio
          label="Acento KPI"
          value={t.accent}
          options={["terracota", "verde", "cian", "ambar"]}
          onChange={(v) => setTweak("accent", v)}
        />
        <TweakRadio
          label="Densidad"
          value={t.density}
          options={["compact", "regular", "comfy"]}
          onChange={(v) => setTweak("density", v)}
        />

        <TweakSection label="Estados de carga"/>
        <TweakToggle
          label="Mostrar esqueletos siempre"
          value={t.showAllSkeletons}
          onChange={(v) => setTweak("showAllSkeletons", v)}
        />
        <TweakSlider
          label="Demora de esqueleto"
          value={t.skeletonHold}
          min={300} max={4000} step={100} unit="ms"
          onChange={(v) => setTweak("skeletonHold", v)}
        />
        <TweakToggle
          label="Mostrar pasos de herramientas"
          value={t.showToolTimeline}
          onChange={(v) => setTweak("showToolTimeline", v)}
        />

        <TweakSection label="Demo"/>
        <TweakButton onClick={() => setTick((x) => x + 1)}>Reproducir desde el inicio</TweakButton>
      </TweaksPanel>
    </div>
  );
}

function sleep(ms) { return new Promise((res) => setTimeout(res, ms)); }

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
