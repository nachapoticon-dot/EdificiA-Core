// icons.jsx
// Lucide-style stroke icons for the EdificIA "Bloques de Respuesta" system.
// Sized 1em, strokeWidth=1.5 to match the existing chat UI vocabulary.
// Construction-domain set (HardHat, DraftingCompass, Building2, Ruler, Layers)
// + helpers used by the response blocks.
//
// All icons accept className + style + size override props.

const Svg = ({ size = 16, className = "", style, children, sw = 1.5 }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth={sw}
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    style={style}
    aria-hidden="true"
  >
    {children}
  </svg>
);

// ─── Construction / architecture domain ─────────────────────────────────────
const HardHat = (p) => (
  <Svg {...p}>
    <path d="M2 18a1 1 0 0 0 1 1h18a1 1 0 0 0 1-1v-1.65A6.5 6.5 0 0 0 17 11V8a3 3 0 0 0-3-3h-4a3 3 0 0 0-3 3v3a6.5 6.5 0 0 0-5 5.35V18z"/>
    <path d="M10 11.5V8"/><path d="M14 11.5V8"/>
    <path d="M2 19h20"/>
  </Svg>
);
const DraftingCompass = (p) => (
  <Svg {...p}>
    <path d="M12 2v3.5"/>
    <circle cx="12" cy="6" r="1.5"/>
    <path d="M12 7.5 6 21"/>
    <path d="M12 7.5 18 21"/>
    <path d="m6.6 19.5 10.8 0"/>
    <path d="M15 13.2a4.5 4.5 0 0 1-6 0"/>
  </Svg>
);
const Building2 = (p) => (
  <Svg {...p}>
    <path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18"/>
    <path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"/>
    <path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"/>
    <path d="M10 6h4"/><path d="M10 10h4"/><path d="M10 14h4"/><path d="M10 18h4"/>
  </Svg>
);
const Ruler = (p) => (
  <Svg {...p}>
    <path d="M21.3 8.7 8.7 21.3a2.4 2.4 0 0 1-3.4 0L2.7 18.7a2.4 2.4 0 0 1 0-3.4L15.3 2.7a2.4 2.4 0 0 1 3.4 0l2.6 2.6a2.4 2.4 0 0 1 0 3.4z"/>
    <path d="m7.5 10.5 2 2"/><path d="m10.5 7.5 2 2"/>
    <path d="m13.5 4.5 2 2"/><path d="m4.5 13.5 2 2"/>
  </Svg>
);
const Layers = (p) => (
  <Svg {...p}>
    <path d="m12.83 2.18 8.94 4.47a1 1 0 0 1 0 1.79l-8.94 4.47a2 2 0 0 1-1.66 0L2.23 8.44a1 1 0 0 1 0-1.79l8.94-4.47a2 2 0 0 1 1.66 0Z"/>
    <path d="m22 12.5-9.17 4.59a2 2 0 0 1-1.66 0L2 12.5"/>
    <path d="m22 17-9.17 4.59a2 2 0 0 1-1.66 0L2 17"/>
  </Svg>
);

// ─── Chat / UI chrome ────────────────────────────────────────────────────────
const ArrowUp = (p) => (<Svg {...p} sw={2.2}><path d="M12 19V5"/><path d="m5 12 7-7 7 7"/></Svg>);
const Paperclip = (p) => (<Svg {...p}><path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.48-8.49l8.57-8.57A4 4 0 1 1 17.99 8.83l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48"/></Svg>);
const Plus = (p) => (<Svg {...p}><path d="M12 5v14"/><path d="M5 12h14"/></Svg>);
const Sparkles = (p) => (<Svg {...p}><path d="m12 3-1.9 4.7L5 9.6l4.5 2.4L11 17l1.6-4.9 4.7-1.9-4.7-2L12 3z"/><path d="M19 3v4"/><path d="M21 5h-4"/></Svg>);
const Search = (p) => (<Svg {...p}><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></Svg>);
const Settings = (p) => (<Svg {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 0 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1A2 2 0 1 1 4.3 16.9l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.1A1.7 1.7 0 0 0 4.6 9a1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9A1.7 1.7 0 0 0 10 3.1V3a2 2 0 0 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></Svg>);

// ─── Files ───────────────────────────────────────────────────────────────────
const FileText = (p) => (<Svg {...p}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M9 13h6"/><path d="M9 17h6"/></Svg>);
const FileSpreadsheet = (p) => (<Svg {...p}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8 13h8"/><path d="M8 17h8"/><path d="M11 11v10"/></Svg>);
const FileCode2 = (p) => (<Svg {...p}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="m9 14-2 2 2 2"/><path d="m15 14 2 2-2 2"/></Svg>);
const Image = (p) => (<Svg {...p}><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="1.6"/><path d="m21 15-4.6-4.6a2 2 0 0 0-2.8 0L3 21"/></Svg>);

// ─── Status / deltas ─────────────────────────────────────────────────────────
const TrendingUp = (p) => (<Svg {...p}><path d="m22 7-9 9-4-4-7 7"/><path d="M16 7h6v6"/></Svg>);
const TrendingDown = (p) => (<Svg {...p}><path d="m22 17-9-9-4 4-7-7"/><path d="M16 17h6v-6"/></Svg>);
const AlertTriangle = (p) => (<Svg {...p}><path d="m10.3 3.86-8.6 14.92A2 2 0 0 0 3.4 22h17.2a2 2 0 0 0 1.7-3.22L13.7 3.86a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4"/><path d="M12 17h.01"/></Svg>);
const CheckCircle2 = (p) => (<Svg {...p}><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></Svg>);
const Info = (p) => (<Svg {...p}><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></Svg>);
const Wrench = (p) => (<Svg {...p}><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94z"/></Svg>);
const Dot = (p) => (<Svg {...p}><circle cx="12" cy="12" r="3" fill="currentColor"/></Svg>);

// ─── Media / timeline glyphs ────────────────────────────────────────────────
const MapPin = (p) => (<Svg {...p}><path d="M20 10c0 7-8 12-8 12s-8-5-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></Svg>);
const Calendar = (p) => (<Svg {...p}><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4"/><path d="M8 2v4"/><path d="M3 10h18"/></Svg>);
const Camera = (p) => (<Svg {...p}><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/></Svg>);
const Maximize2 = (p) => (<Svg {...p}><path d="M15 3h6v6"/><path d="M9 21H3v-6"/><path d="m21 3-7 7"/><path d="m3 21 7-7"/></Svg>);
const Download = (p) => (<Svg {...p}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/></Svg>);
const Eye = (p) => (<Svg {...p}><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></Svg>);
const ChevronRight = (p) => (<Svg {...p}><path d="m9 18 6-6-6-6"/></Svg>);
const ChevronDown = (p) => (<Svg {...p}><path d="m6 9 6 6 6-6"/></Svg>);
const X = (p) => (<Svg {...p}><path d="M18 6 6 18"/><path d="m6 6 12 12"/></Svg>);
const Star = (p) => (<Svg {...p}><path d="m12 17.27 6.18 3.73-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></Svg>);
const Trash = (p) => (<Svg {...p}><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6 18 20a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></Svg>);
const Truck = (p) => (<Svg {...p}><path d="M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2"/><path d="M15 18H9"/><path d="M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14"/><circle cx="17" cy="18" r="2"/><circle cx="7" cy="18" r="2"/></Svg>);
const Boxes = (p) => (<Svg {...p}><path d="M2.97 12.92A2 2 0 0 0 2 14.63v3.24a2 2 0 0 0 .97 1.71l3 1.8a2 2 0 0 0 2.06 0L11 19.71V16l-4 2.4-4-2.4"/><path d="M7 16.5 2.5 14"/><path d="M7 16.5v5.17"/><path d="M7 16.5 11.5 14"/><path d="M14.97 12.92A2 2 0 0 0 14 14.63v3.24a2 2 0 0 0 .97 1.71l3 1.8a2 2 0 0 0 2.06 0l3-1.8a2 2 0 0 0 .97-1.71v-3.24a2 2 0 0 0-.97-1.71L20 11"/><path d="M19 16.5 14.5 14"/><path d="M19 16.5v5.17"/><path d="M19 16.5 23.5 14"/><path d="M8.97 5.92A2 2 0 0 0 8 7.63v3.24a2 2 0 0 0 .97 1.71l3 1.8a2 2 0 0 0 2.06 0l3-1.8A2 2 0 0 0 18 10.87V7.63a2 2 0 0 0-.97-1.71l-3-1.8a2 2 0 0 0-2.06 0z"/></Svg>);

// Globally available
Object.assign(window, {
  HardHat, DraftingCompass, Building2, Ruler, Layers,
  ArrowUp, Paperclip, Plus, Sparkles, Search, Settings,
  FileText, FileSpreadsheet, FileCode2, Image,
  TrendingUp, TrendingDown, AlertTriangle, CheckCircle2, Info, Wrench, Dot,
  MapPin, Calendar, Camera, Maximize2, Download, Eye, ChevronRight, ChevronDown, X, Star, Trash, Truck, Boxes,
});
