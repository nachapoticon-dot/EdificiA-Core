# IMPLEMENTATION_GUIDE.md — Bloques de Respuesta

**Diseñador principal:** UI/UX (este turno)
**Destinatario:** Claude Code (implementación técnica)
**Repo objetivo:** [`nachapoticon-dot/EdificIA`](https://github.com/nachapoticon-dot/EdificIA) · rama `main`
**Convenciones:** Next.js 16 (App Router) · TypeScript strict · Tailwind v4 · Shadcn · AI SDK v6 · Recharts · `lucide-react`

> Este documento es la fuente de verdad para llevar el prototipo en `Bloques de Respuesta.html` a producción. Las decisiones visuales ya están tomadas (tokens, dimensiones, copys) — Claude Code debe enfocarse en **cableado a la AI**, **tools nuevas**, **persistencia**, **accesibilidad**, y **refactor de carpetas**.

---

## 1. Inventario de componentes a crear / actualizar

| Componente | Archivo destino | Estado actual | Acción |
|---|---|---|---|
| `BlockShell` | `src/components/chat/blocks/BlockShell.tsx` | nuevo | crear — wrapper común (header `FIG. N`, icon pill, body, footer, botones Maximize/Download) |
| `MetricsBlock` | `src/components/chat/blocks/MetricsBlock.tsx` | refactor de `ChartBlock.tsx` | extender con strip de **KPIs (4 tarjetas con deltas)** + barras existentes |
| `MediaBlock` | `src/components/chat/blocks/MediaBlock.tsx` | nuevo | grilla 1 hero + 3 thumbs, badges por tipo (`PLANO`/`RENDER`/`INSPECCIÓN`), botón zoom |
| `ComparisonBlock` | `src/components/chat/blocks/ComparisonBlock.tsx` | refactor de `ComparisonTable.tsx` | versión "proveedores/materiales" con **ranking**, **badge RECOMENDADO**, columnas dinámicas |
| `TimelineBlock` | `src/components/chat/blocks/TimelineBlock.tsx` | nuevo | Gantt horizontal con línea HOY, hitos, fases con barra de progreso |
| `MetricsSkeleton` | `…/blocks/skeletons/MetricsSkeleton.tsx` | nuevo | mismo footprint que `MetricsBlock` |
| `MediaSkeleton` | `…/blocks/skeletons/MediaSkeleton.tsx` | nuevo | 1 hero + 3 thumbs vacíos |
| `ComparisonSkeleton` | `…/blocks/skeletons/ComparisonSkeleton.tsx` | nuevo | header + 4 filas |
| `TimelineSkeleton` | `…/blocks/skeletons/TimelineSkeleton.tsx` | nuevo | 5 filas Gantt |
| `ResponseBlock` router | `…/blocks/index.tsx` | nuevo | switch sobre `kind` + `loading` |

### Tokens visuales (todos ya viven en `src/app/globals.css` — **no agregar nada**)

- Fondo card: `bg-card` · borde: `border-border`
- Acento principal: `var(--primary)` (terra-400 en dark)
- **Verde construcción** (KPI positivo / fases completadas) → declarar `--green: oklch(0.72 0.16 145);` en `:root` y `.dark` de `globals.css`
- **Cian técnico** (KPI neutro / metadata) → declarar `--cyan: oklch(0.74 0.13 215);`
- Warn (alertas): ya existe `--warn`
- Tipografía mono para labels técnicos: `font-mono` con `tracking-[0.08em] uppercase text-[10px]`
- Numérica tabular: clase `eb-num` (ya existe)

---

## 2. Schemas Zod a definir (`src/lib/validators/blocks.ts`)

Todas las herramientas que producen bloques deben devolver shapes validados con Zod, compartidos E2E. Crear nuevo archivo:

```ts
import { z } from "zod";

export const KpiSchema = z.object({
  label: z.string(),                        // "TOTAL OBRA"
  value: z.string(),                        // ya formateado, AR-style
  delta: z.number().optional(),             // %, signed
  alert: z.boolean().optional(),            // resalta en --warn
  sub:   z.string().optional(),             // "vs presupuesto base"
});

export const BarSchema = z.object({
  label: z.string(),
  value: z.number(),                        // siempre en $ AR
  pct:   z.number().optional(),             // incidencia %
  alert: z.boolean().optional(),
});

export const MetricsSpec = z.object({
  kind: z.literal("metrics"),
  title: z.string(),
  kpis: z.array(KpiSchema).min(2).max(4),
  bars: z.array(BarSchema).min(1).max(12),
  totalLabel: z.string().default("Σ"),
  footer: z.string().optional(),
});

export const MediaItem = z.object({
  kind: z.enum(["plano", "render", "obra"]),
  title: z.string(),
  date: z.string().optional(),              // ya formateada DD/MM/YYYY
  location: z.string().optional(),
  ext: z.string().optional(),               // "DXF · 4.2 MB"
  documentId: z.string(),                   // FK a documents.id — para resolver URL
  thumbnailUrl: z.string().url().optional(),// pre-firmada InsForge
});
export const MediaSpec = z.object({
  kind: z.literal("media"),
  title: z.string(),
  obra: z.string(),                         // código de obra
  items: z.array(MediaItem).min(1).max(8),
});

export const CompCol = z.object({
  key:    z.string(),
  label:  z.string(),
  format: z.enum(["currency", "duration_h", "boolean_iram", "count_obras", "raw"]),
  alertThreshold: z.number().optional(),
});
export const CompItem = z.object({
  name: z.string(),
  sub:  z.string().optional(),
  score: z.number().min(0).max(100),
  values: z.record(z.union([z.string(), z.number(), z.boolean()])),
});
export const ComparisonSpec = z.object({
  kind: z.literal("comparison"),
  title: z.string(),
  rankBy: z.string(),
  cols: z.array(CompCol).min(2).max(6),
  items: z.array(CompItem).min(2).max(8),
});

export const TimelinePhase = z.object({
  name: z.string(),
  crew: z.string().optional(),
  start: z.number().int().nonnegative(),    // día desde inicio
  end:   z.number().int().positive(),
});
export const TimelineMilestone = z.object({
  label: z.string(),
  day:   z.number().int().nonnegative(),
  note:  z.string().optional(),
});
export const TimelineSpec = z.object({
  kind: z.literal("timeline"),
  title: z.string(),
  totalDays: z.number().int().positive(),
  todayDay:  z.number().int().nonnegative(),
  months:    z.array(z.string()).min(2).max(12),
  phases:    z.array(TimelinePhase).min(1).max(20),
  milestones: z.array(TimelineMilestone).max(10),
});

export const BlockSpec = z.discriminatedUnion("kind", [
  MetricsSpec, MediaSpec, ComparisonSpec, TimelineSpec,
]);
export type BlockSpec = z.infer<typeof BlockSpec>;
```

**Acción:** importar este schema tanto en (a) las **AI tools** (validación de output del agente, lado server) como en (b) el **MessageBubble** (validación defensiva antes de renderizar, lado cliente).

---

## 3. AI Tools nuevas / a actualizar (`src/lib/ai/tools/*.ts`)

El agente debe poder elegir entre estas herramientas según la intención del usuario. **Todas devuelven un objeto que matchea `BlockSpec`.**

| Tool | Reemplaza | Cuándo dispararla |
|---|---|---|
| `proyectar_metricas` | `generar_grafica` (parcialmente) | el usuario pide auditoría, incidencias, KPIs, comparación contra CAC |
| `proyectar_legajo_grafico` | `buscar_en_base_documental` (cuando el query es visual) | el usuario pide ver planos, renders, fotos de obra, "muéstrame" |
| `proyectar_comparativa` | `comparar_presupuestos` (extendida) | usuario pide comparar proveedores, materiales, ofertas |
| `proyectar_cronograma` | (nueva) | usuario pregunta por cronograma, avance, hitos, Gantt |

### Pasos:

1. Definir las descriptions de las tools con prompts ESTRICTOS (ver §6, system prompt updates).
2. Cada handler debe:
   - Cargar contexto desde Qdrant + Postgres (multi-tenant: filtro por `organization_id`).
   - Calcular agregados con `src/lib/math-engine/`.
   - Devolver `BlockSpec` validado con Zod.
   - En caso de error, devolver `{ kind: "error", message }` — **NO** levantar excepción al stream (la UI muestra fallback).

3. Para `proyectar_legajo_grafico`:
   - Resolver `thumbnailUrl` con presigned URLs de InsForge Storage (TTL = 1h).
   - Si el ítem es DXF, generar thumbnail PNG con `dxf-viewer` + `node-canvas` en build/CRON (no on-the-fly).

4. Para `proyectar_cronograma`:
   - Leer cronograma base desde `obras.metadata.cronograma` (campo JSONB nuevo en migration).
   - Si no existe, **devolver vacío y dejar que el agente proponga uno** vía LLM tool-call recursivo (`sugerir_cronograma`).

---

## 4. Integración en `MessageBubble.tsx`

Reemplazar el bloque `SpecialToolPart` con un router:

```tsx
import { ResponseBlock } from "./blocks";
import { BlockSpec } from "@/lib/validators/blocks";

function SpecialToolPart({ part }: { part: UIMessagePart }) {
  const ti = getToolInvocation(part);
  const isPending = ti?.state === "call" || ti?.state === "partial-call";
  const toolName = ti?.toolName ?? "";

  const BLOCK_TOOLS: Record<string, BlockSpec["kind"]> = {
    proyectar_metricas:        "metrics",
    proyectar_legajo_grafico:  "media",
    proyectar_comparativa:     "comparison",
    proyectar_cronograma:      "timeline",
  };

  const kind = BLOCK_TOOLS[toolName];
  if (!kind) return /* fallback existing */;

  // Loading state → skeleton with correct footprint
  if (isPending) return <ResponseBlock kind={kind} loading />;

  // Validate before render — defensive
  const parsed = BlockSpec.safeParse(ti.result);
  if (!parsed.success) {
    return <FallbackErrorBlock toolName={toolName} />;
  }
  return <ResponseBlock kind={kind} spec={parsed.data} />;
}
```

**Crucial — el skeleton se muestra MIENTRAS la tool corre.** No agregar timers artificiales; el AI SDK ya emite `state: "call"` desde el primer chunk del tool.

---

## 5. Refactor de carpetas (mover archivos existentes)

```
src/components/chat/
├── blocks/                         ← NUEVO
│   ├── index.tsx                   (router ResponseBlock)
│   ├── BlockShell.tsx
│   ├── MetricsBlock.tsx            ← (era ChartBlock.tsx — migrar)
│   ├── MediaBlock.tsx
│   ├── ComparisonBlock.tsx         ← (era ComparisonTable.tsx — migrar y extender)
│   ├── TimelineBlock.tsx
│   └── skeletons/
│       ├── MetricsSkeleton.tsx
│       ├── MediaSkeleton.tsx
│       ├── ComparisonSkeleton.tsx
│       └── TimelineSkeleton.tsx
├── MessageBubble.tsx               (actualizar imports)
├── ChatInput.tsx
└── SessionSidebar.tsx
```

Mantener `ChartBlock.tsx` y `ComparisonTable.tsx` como **re-exports temporales** durante una versión para no romper consumers:

```ts
// src/components/chat/ChartBlock.tsx
export { MetricsBlock as ChartBlock } from "./blocks/MetricsBlock";
export type { MetricsSpec as ChartSpec } from "@/lib/validators/blocks";
```

---

## 6. Refinamiento del System Prompt (`src/lib/ai/prompt.ts`)

Agregar al system prompt directivas estrictas:

```
COMPORTAMIENTO DE PROYECCIÓN DE BLOQUES
========================================
Cuando la respuesta involucre datos cuantitativos, planos, comparativas o
cronogramas, SIEMPRE proyectá un Bloque de Respuesta en lugar de listar texto.

Mapeo intención → tool:
  • Auditoría, incidencias, KPIs, desvíos contra CAC → proyectar_metricas
  • "Ver / mostrar" planos, renders, fotos de obra   → proyectar_legajo_grafico
  • Compará proveedores, materiales, ofertas         → proyectar_comparativa
  • Cronograma, avance, hitos, Gantt                 → proyectar_cronograma

Reglas:
  1. NUNCA inventes números. Si no tenés contexto suficiente, decilo
     explícitamente y NO disparres la tool.
  2. Después de proyectar un bloque, escribí UN solo párrafo (≤ 60 palabras)
     interpretando el bloque desde la óptica de un Auditor Técnico Senior:
     marcá excepciones, atribuí causas técnicas, sugerí una próxima acción.
  3. Citá siempre documento + página/sección de donde sacaste cada dato.
     Formato: «Plano arq. R7, lámina A-03; Cómputo R3, fila 142».
  4. Si la consulta excede tu contexto documental (RAG sin matches > 0.8),
     decí: «No tengo ese dato en el legajo de la obra. Subí el documento o
     pedile a un miembro con acceso que lo cargue.»
  5. Tono: preciso, conciso, basado en normas (CIRSOC, IRAM, Ley 13.512).
     Sin floreos. Castellano rioplatense.
```

---

## 7. Estados de carga (skeletons) — protocolo de UX

| Etapa | Lo que ve el usuario | Duración |
|---|---|---|
| 1. Usuario manda mensaje | Toast suave, scroll al final | 0 ms |
| 2. AI elige tool (LLM round-trip) | `<ToolTimeline>` — pill row con "Calculando…" + spinner | ~600–1800 ms |
| 3. Tool corriendo | **Skeleton del bloque** (`<MetricsSkeleton/>` etc.) | hasta que termine la tool |
| 4. Tool retorna | Cross-fade del skeleton al bloque real (`@keyframes eb-rise`) | 240 ms |
| 5. AI escribe interpretación | Texto debajo, streaming character-by-character | 1–3 s |

**Implementar el cross-fade** con `AnimatePresence` de Framer Motion (ya está como dependencia).

```tsx
<AnimatePresence mode="wait">
  {isPending
    ? <motion.div key="sk" exit={{ opacity: 0 }}><Skeleton/></motion.div>
    : <motion.div key="ok" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}>
        <Block spec={spec}/>
      </motion.div>}
</AnimatePresence>
```

---

## 8. Accesibilidad — verificaciones bloqueantes

- [ ] Contraste AA en dark mode para TODAS las clases nuevas (`--muted-foreground` ≥ 4.5:1 sobre `--background`; los `eb-mono-muted` están al límite en compact density — auditar con `@axe-core/react`).
- [ ] **Skeletons con `aria-busy="true"` y `aria-label`** descriptivo (ej. "Cargando métricas de obra").
- [ ] Bloques con `role="region"` y `aria-labelledby` apuntando al título.
- [ ] La línea **HOY** del Gantt debe estar disponible para screen readers como `aria-label="Fecha actual: día 132 de 220"`.
- [ ] Foco visible en todos los botones (focus-ring shadcn).
- [ ] Tablas comparativas: usar `<table>` semántico — el prototipo usa `<div role="grid">` por performance pero **producción debe ser `<table>` con `scope`** para screen readers.

---

## 9. Performance

- **Recharts es pesado**. Ya está en `package.json`, pero **el bloque de métricas no lo usa** (barras horizontales hand-rolled en SVG). Mantener Recharts solo para `chartType: "pie" | "line"` (el flujo actual). Para barras nuevas, mantener el SVG custom — pesa <2KB.
- Memoizar `ranked` en `ComparisonBlock` con `useMemo(deps: [spec.items])`.
- Las tiles del `MediaBlock` deben usar `loading="lazy"` y un `IntersectionObserver` para revelar imágenes solo en viewport (cuando lleguen los `thumbnailUrl` reales).
- El SVG del Gantt re-renderiza en cada update de `todayDay`. Calcular `today % position` con CSS custom properties (`--today-pct: 60`) para evitar re-render del DOM completo.

---

## 10. Migración de DB (`migrations/0XX_obras_cronograma.sql`)

```sql
ALTER TABLE obras
  ADD COLUMN IF NOT EXISTS cronograma JSONB DEFAULT NULL;

-- Para que la tool proyectar_cronograma pueda leer/escribir el plan base.
-- Shape esperado: { totalDays, phases: [...], milestones: [...] }
-- Validado en runtime con TimelineSpec.

COMMENT ON COLUMN obras.cronograma IS
  'Cronograma base de la obra en formato BlockSpec[timeline]. todayDay se
   calcula on-the-fly desde obras.fecha_inicio.';
```

Y un endpoint nuevo `POST /api/projects/[id]/cronograma` con guards de rol (`engineer`+).

---

## 11. Iconografía — uso estricto de `lucide-react`

El prototipo usa SVG inline para no depender de la librería. **En producción, importar de `lucide-react`** (ya en `package.json` v1.12.0):

```tsx
import { HardHat, DraftingCompass, Building2, Ruler, Layers,
         TrendingUp, TrendingDown, CheckCircle2, AlertTriangle,
         Calendar, MapPin, Camera, Maximize2, Download } from "lucide-react";
```

Mapping de iconos por bloque:
- `MetricsBlock`    → `Building2`
- `MediaBlock`      → `DraftingCompass`
- `ComparisonBlock` → `Layers`
- `TimelineBlock`   → `HardHat`
- Status: `CheckCircle2` (done) · `AlertTriangle` (warn) · `TrendingUp/Down` (delta)

**Stroke width = 1.5** consistente en toda la UI (mirror del resto de la app).

---

## 12. Testing

- [ ] Snapshot test de cada bloque con dataset mínimo, medio y "edge case" (1 ítem, valores null, score = 0).
- [ ] Test de validación Zod: enviar un spec mal formado a cada bloque, asegurarse que el `FallbackErrorBlock` se renderiza.
- [ ] Test E2E con Playwright: usuario envía "¿Cómo va la obra?" → mock de la tool `proyectar_cronograma` → asserta que el skeleton aparece **antes** que el bloque real.
- [ ] Test de regresión visual con Chromatic / Percy sobre los 4 bloques + 4 skeletons.

---

## 13. Lo que SÍ está resuelto en el prototipo (no rehacer)

- ✅ Layout completo del chat dashboard (sidebar + header + chat scroll + input).
- ✅ Tokens visuales (todos viven en `globals.css` ya existente — agregar solo `--green` y `--cyan`).
- ✅ 4 bloques con animaciones de entrada (`eb-rise`).
- ✅ 4 skeletons con shimmer (`eb-shimmer`).
- ✅ Mock de tool timeline progresivo.
- ✅ Datos de demo realistas para Las Lomas — Torre A (usar como seed de tests).
- ✅ Tweaks panel con switches de accent, density y skeleton override (no portar — sólo era para revisión).

---

## 14. Lo que tiene que decidir alguien antes de implementar

| Decisión | Owner | Default sugerido |
|---|---|---|
| ¿El `MediaBlock` permite drag-to-reorder dentro del legajo? | Producto | No (read-only en chat; sí en `/dashboard/documents`) |
| ¿El Gantt es editable inline o solo lectura? | Producto | Solo lectura en chat; edición en una vista dedicada |
| ¿Score del `ComparisonBlock` se calcula server-side o lo decide el LLM? | Tech lead | Híbrido: pesos en BD por org, ranking en `math-engine` |
| ¿Cuántos KPIs entran en el strip — fijo en 4 o variable? | Diseño | Fijo en 4 para mantener grid; si hay <4, padding |
| ¿Persistir bloques renderizados en `messages.parts` o re-disparar la tool al recargar la sesión? | Tech lead | Persistir el output de la tool en `tool_results` JSONB; barato y determinístico |

---

**Fin del handover.** El prototipo HTML (`Bloques de Respuesta.html`) corre standalone para revisión. Cualquier duda visual: abrir el archivo, hacer click en "Reproducir desde el inicio" (esquina superior derecha), o togglear "Mostrar esqueletos siempre" en el panel Tweaks.
